/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.SoulFightDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author User
 */
public class AccountDBDAO {
    
    	public static Connection getConnection(){
            Connection con = null;
            try{
                Class.forName("com.mysql.cj.jdbc.Driver"); 
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/soulfightdb?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC", "root", "68054680aS");
            }catch(Exception ex) {
                System.out.println(ex);
            }
            return con;
	}
	
	public static int save(AccountDB account) {
		
		int status = 0;
		try {			
			Connection con = getConnection();
			PreparedStatement pst = con.prepareStatement("insert into account (userID, username, password) values (?,?,?)" );                                                            
			pst.setInt(1, account.getUserID());
			pst.setString(2, account.getUsername());
			pst.setString(3, account.getPassword());
			
			status=pst.executeUpdate();			
		}catch(Exception ex) {
			System.out.println(ex);
		}
		
		return status;
	}
	
	public static int update (AccountDB account) {
		
		int status = 0;
		
		try {
			Connection con = getConnection();
			PreparedStatement pst= con.prepareStatement("update account set username=?, password=? where userID=?");
			pst.setString(1, account.getUsername());
			pst.setString(2, account.getPassword());
			pst.setInt(3, account.getUserID());
			
			status=pst.executeUpdate();
		}catch(Exception ex) {
			System.out.println(ex);
		}
		System.out.println(status);
		return status;
	}
	
	public static int delete (AccountDB account) {
		
		int status = 0;
		
		try {
			Connection con = getConnection();
			PreparedStatement pst= con.prepareStatement("delete from account where id=?");
			pst.setInt(1, account.getUserID());
			
			status=pst.executeUpdate();
		}catch(Exception ex) {
			System.out.println(ex);
		}	
		return status;
	}
	
	public static List<AccountDB>getAllRecord() {
		
		List<AccountDB>list = new ArrayList<AccountDB>();
		
		try {
			Connection con = getConnection();
			PreparedStatement pst= con.prepareStatement("select * from account");
			ResultSet rs = pst.executeQuery();
			while(rs.next()) {
				AccountDB ac = new AccountDB();
				ac.setUserID(rs.getInt("userID"));
				ac.setUsername(rs.getString("username"));
				ac.setPassword(rs.getString("password"));

				list.add(ac);
			}
		}catch(Exception ex) {
			System.out.println(ex);
		}	
		return list;
	}
	
public static AccountDB getRecordbyId(int id) {
		
		AccountDB ac = null;
		
		try {
			Connection con = getConnection();
			PreparedStatement pst= con.prepareStatement("select * from account where userID = ?");
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			ac = new AccountDB();
			while(rs.next()) {
				ac.setUserID(rs.getInt("userID"));
				ac.setUsername(rs.getString("username"));
				ac.setPassword(rs.getString("password"));
	
			}
		}catch(Exception ex) {
			System.out.println(ex);
		}	
		return ac;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
}
