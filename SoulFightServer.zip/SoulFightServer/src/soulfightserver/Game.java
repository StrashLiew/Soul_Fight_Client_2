/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soulfightserver;

/**
 *
 * @author User
 */
import com.example.soul_fight.Account;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Game implements Runnable{
    ClientHandler player1, player2;
    double p1Health, p2Health;
    boolean gameIsOver;
    ObjectOutputStream oos1, oos2;
    ObjectInputStream ois1, ois2;
    Game(ClientHandler player1, ClientHandler player2){
        this.player1 = player1;
        this.player2 = player2;
        this.p1Health = 100;
        this.p2Health = 100;
        this.ois1 = player1.ois;
        this.ois2 = player2.ois;
        this.oos1 = player1.oos;
        this.oos2 = player2.oos;
       
        
        gameIsOver = false;
    }
    
    public synchronized void takeDamage(ClientHandler source, double damage){        
        if(source == player2){
            if(damage == -3){
                player1.sendWin();
            }
            p1Health -= damage;
            player2.broadcastDmg(damage);
            System.out.println(player1.clientName +" has taken "+damage+ " damage.");
            if(p1Health <= 0){
                GameOver(player1, player2);
            }
        }
        else if(source == player1){
            if(damage == -3){
                player2.sendWin();
            }
            p2Health -= damage;
            player1.broadcastDmg(damage);
            System.out.println(player2.clientName +" has taken "+damage+ " damage.");
            if(p2Health <= 0){
                GameOver(player2, player1);
            }
        }          
        
    }
   
    public void GameOver(ClientHandler loser, ClientHandler winner){
        System.out.println(loser.clientName + " has lost.");
        System.out.println("CONGRATULATIONS "+winner.clientName + " !!!");
        loser.sendLost();
        winner.sendWin();
        gameIsOver = true;
    }
    
    public int generateSeed(){
        return new Random().nextInt(1000);
    }
    
    
    public void P1ListenDamage(){
        new Thread(){
            @Override
            public void run() {
                System.out.println("P1 Listening for damage...");
                while(player1.socket.isConnected()){
                    try {
                        Object o1 = ois1.readObject();
                        if(o1 instanceof Double damage){
                            takeDamage(player1, damage);
                            player1.broadcastDmg(damage);
                        }
                    }catch (IOException | ClassNotFoundException ex) {
                        Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
                    }   
                }                     
            }
        }.start();
    }
    
    public void P2ListenDamage(){            
         new Thread(){
            @Override
            public void run() {
                System.out.println("P2 Listening for damage...");
                while(player2.socket.isConnected()){
                     try {  
                        Object o2 = ois2.readObject();
                        if(o2 instanceof Double damage){
                             takeDamage(player2, damage);
                             player2.broadcastDmg(damage);
                        }
                    }catch (IOException | ClassNotFoundException ex) {
                        Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }                        
            }
        }.start();
    }

    public synchronized void startListen(){
        
    }
       
    @Override
    public void run(){ 
        System.out.println("Game between " +player1.clientName + " and " +player2.clientName + " has started.");
        int seed = generateSeed();
//        player1.sendSeed(seed);
//        player2.sendSeed(seed);    
//        
        System.out.println("Seed: "+seed);
        try {
           oos1.writeObject(seed);
           oos1.flush();
           oos2.writeObject(seed);
           oos2.flush();
        } catch (IOException ex) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        } 
//        P1ListenDamage();          
//        P2ListenDamage(); 
        while(true){
           
            if(gameIsOver){
                System.out.println("Break");
                break;
            }
        }
    }
}
