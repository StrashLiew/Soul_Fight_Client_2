/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soulfightserver;

import com.example.soul_fight.RoomSettings;

/**
 *
 * @author User
 */
public class Message {
    
    public String username;
    public String password;
    public double dmg;
    public int lobbyID;
    public String points;
    public RoomSettings roomSettings;
    
    Message(String username, String password, double dmg, int lobbyID, String points, RoomSettings roomSettings){
        this.username = username;
        this.password = password;
        this.dmg = dmg;
        this.points = points;
        this.roomSettings = roomSettings;
    }   
}
