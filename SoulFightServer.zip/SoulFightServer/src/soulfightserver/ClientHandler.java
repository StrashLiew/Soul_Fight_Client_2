/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soulfightserver;

import com.SoulFightDB.AccountDB;
import com.example.soul_fight.RoomSettings;
import com.example.soul_fight.Account;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class ClientHandler implements Runnable{
    public static ArrayList<ClientHandler> clientHandlers = new ArrayList<>();
    public Socket socket;
    public ObjectOutputStream oos;
    public ObjectInputStream ois;
    public String clientName;
    private SoulFightServer parent;
    boolean hasJoinedRoom = false;
    Thread matchBroadcastThread;
    WaitingRoom inRoom;
    Game inGame;
    public ClientHandler(Socket socket, SoulFightServer parent) throws ClassNotFoundException{
        try{
            this.parent = parent;
            this.socket = socket;
            this.oos = new ObjectOutputStream(this.socket.getOutputStream());
            this.ois = new ObjectInputStream(this.socket.getInputStream());
//            this.clientName = ((Object)ois.readObject()).username;
            this.clientName = (String)ois.readObject();
           clientHandlers.add(this);
           System.out.println(clientName+" has been connected to server.");
        }catch(IOException e){
            closeEverything(socket, oos, ois);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @Override
    public void run(){
        //Message objectFromClient;        
//        double damageFromClient;
        while(socket.isConnected()){
            try{
                Object o = ois.readObject();
//                Account account = (Account) ois.readObject();
//                System.out.println("Username: "+account.username);
//                System.out.println("Password: "+account.password);
                   if(o instanceof Account account){
                      System.out.println("Username: "+account.username);
                      System.out.println("Password: "+account.password);
                      verifyAccount(account);
                   }else if(o instanceof String func){
                        switch(func){
                            case "sendRoomList":  //When user enter the room list page, they will call this
                                sendRoomList();
                                break;
                            case "createRoom":
                                System.out.println("Attempt to create room");
                                RoomSettings rs = (RoomSettings)ois.readObject();
                                System.out.println("RoomSettings: "+Arrays.toString(rs.operators));
                                createRoom(rs);
                                break;
                            case "joinRoom":
                                int roomIndex= (int)ois.readObject();
                                joinRoom(roomIndex);
                                break;
                            case "startMatch":
                                callStartMatch();
                            {
                                try {
                                    matchBroadcastThread.join();
                                } catch (InterruptedException ex) {
                                    Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
                                }
                            }
                                broadcastMatchStart();                                                              
                                break;
                            case "getRoomID":
                                getCurrentRoomID();
                                break;
                            case "getRoomHost":
                                getCurrentRoomHost();
                                break;
                            case "getRoomSettings":
                                getRoomSettings();
                                break;
                            

                        }
                   }else if(o instanceof Double damage){
                         inGame.takeDamage(this, damage);
                    }
                           
            }catch(IOException e){
                closeEverything(socket, oos, ois);
                break;
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void verifyAccount(Account account){
        for(AccountDB acc : parent.accounts){
            if(account.username.equals (acc.getUsername()) && account.password.equals(acc.getPassword())){
                System.out.println(account.username + " is a verified user.");
                try {
                    this.oos.writeObject(true);
                    this.oos.flush();
                    this.clientName = account.username;
                    System.out.println("Anonymous is now "+this.clientName);
                    return;
                } catch (IOException ex) {
                    Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
                }  
            }     
        }
        try {
            this.oos.writeObject(false);
            this.oos.flush();
        } catch (IOException ex) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
    }
    
    public void createRoom(RoomSettings rs){
        if(!this.hasJoinedRoom){
            WaitingRoom waitingRoom = new WaitingRoom(this, rs);
            parent.roomList.add(waitingRoom);
            hasJoinedRoom = true;
            inRoom = waitingRoom;
            Thread roomThread = new Thread(waitingRoom);
            roomThread.start();
        }     
    }
    
    public void joinRoom(int roomIndex){
        if(!this.hasJoinedRoom){
            hasJoinedRoom = true;
            parent.roomList.get(roomIndex).addPlayer(this);    
            inRoom = parent.roomList.get(roomIndex);
        }      
    }  
    
    public void getRoomSettings(){
        if(this.hasJoinedRoom){    
            try {
                System.out.println("Sending room settings of room " +  parent.roomList.indexOf(inRoom));
                this.oos.writeObject(inRoom.roomSettings);
                this.oos.flush();
            } catch (IOException ex) {
                Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }   
    }
    
    public void getCurrentRoomID() {
        if(this.hasJoinedRoom) {
            try {
                System.out.println("Sending room id: " + parent.roomList.indexOf(inRoom));
                this.oos.writeObject(parent.roomList.indexOf(inRoom));
                this.oos.flush();
            } catch (IOException ex) {
                Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    public void getCurrentRoomHost() {
        if(this.hasJoinedRoom) {
            try {
                this.oos.writeObject(inRoom.player1.clientName);
                this.oos.flush();
            } catch (IOException ex) {
                Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    public void notifyPlayerJoin(String playerTwoName) {
        try {
            this.oos.writeObject("someoneJoined");
            this.oos.flush();
            this.oos.writeObject(playerTwoName);
            this.oos.flush();
        } catch (IOException ex) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void sendRoomList(){
        try {
            this.oos.writeObject(parent.roomList.size());
            this.oos.flush();
            System.out.println(parent.roomList.size());
            if(parent.roomList.size() <= 0){
                this.oos.writeObject("No rooms available at the moment.");
                this.oos.flush(); 
            }
            else{
                for (int i = 0; i<parent.roomList.size();i++) {
                    System.out.println(parent.roomList.get(i).player1.clientName);
                    this.oos.writeObject(parent.roomList.get(i).player1.clientName);
                    this.oos.flush();                
                }   
            }        
        } catch (IOException ex) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void callStartMatch(){
        matchBroadcastThread = new Thread(){
            @Override
            public void run(){
                inRoom.matchStart();
            }      
        };
        matchBroadcastThread.start();
        
    }
    
    public void broadcastMatchStart(){
        //send to client for intent change..
        for(ClientHandler clientHandler: clientHandlers){
            try {
               clientHandler.oos.writeObject("Begin Match");
               clientHandler.oos.flush();
            }catch (IOException ex) {
                Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
            }  
        }
    }
    
    //sends the damage value to the other user
    public void broadcastDmg(double damage){
        for(ClientHandler clientHandler: clientHandlers){
            try{
                if(clientHandler != this){
                    System.out.println("server: "+damage);
                    clientHandler.oos.writeObject(damage);
                    clientHandler.oos.flush();
                }
            }catch(IOException e){
                closeEverything(socket, oos, ois);
                break;
            }
        }
    }
    
    public void sendSeed(int seed){
        System.out.println("Seed: "+seed);
        try {
            this.oos.writeObject(seed);
            this.oos.flush();
        } catch (IOException ex) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        }  
    }
    
    public void sendLost(){
        try {
            System.out.println(this.clientName + ": -2");
            this.oos.writeObject(-2.0);
            this.oos.flush();
        } catch (IOException ex) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    public void sendWin(){
        try {
            System.out.println(this.clientName + ": -1");
            this.oos.writeObject(-1.0);
            this.oos.flush();
        } catch (IOException ex) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    public void sendSurrender(){
        try {
            System.out.println(this.clientName + ": -1");
            this.oos.writeObject(-3.0);
            this.oos.flush();
        } catch (IOException ex) {
            Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    public void removeClientHandler(){
        clientHandlers.remove(this);
        System.out.println(clientName + " has left the game!");
    }
    
    public void closeEverything(Socket socket, ObjectOutputStream oos, ObjectInputStream ois){
        removeClientHandler();
        try{
            if(oos!=null){
                oos.close();
            }
            if(ois!=null){
                ois.close();
            }
            if(socket!=null){
                socket.close();
            }
            if(!parent.roomList.isEmpty()){
                parent.roomList.remove(inRoom);
            }
        }catch(IOException e){
            System.out.println(e);
        }
    }
    
}
