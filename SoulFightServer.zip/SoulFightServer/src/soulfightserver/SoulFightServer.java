/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package soulfightserver;

import com.SoulFightDB.AccountDB;
import com.SoulFightDB.AccountDBDAO;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SoulFightServer {
    
    private ServerSocket serverSocket;
    public static ArrayList<WaitingRoom> roomList = new ArrayList<>();
    public static  List<AccountDB> accounts;
    public SoulFightServer(ServerSocket serverSocket){
        this.serverSocket = serverSocket;
    }
    
    public void  startServer(){
        try{
            while(!serverSocket.isClosed()){
                Socket socket = serverSocket.accept();
                System.out.println("A new client has connected!");
                ClientHandler clientHandler = new ClientHandler(socket, this);                
                Thread thread = new Thread(clientHandler);
                thread.start();
            }
        }catch(IOException e){
            System.out.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(SoulFightServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void main(String[] args){
        ServerSocket serverSocket;
        accounts = AccountDBDAO.getAllRecord();
        for(AccountDB acc : accounts){
            System.out.println(acc);
        }     
        try {
            serverSocket = new ServerSocket(1234);
            SoulFightServer server = new SoulFightServer(serverSocket);
             server.startServer();
        } catch (IOException ex) {
            Logger.getLogger(SoulFightServer.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
//    public static void main(String[] args) {
//        String messageFromClient;
//        try {
//            ServerSocket serverSocket = new ServerSocket(1234);
//            while(true) {
//                Socket socket = serverSocket.accept();
//                DataInputStream inputFromClient = new DataInputStream(socket.getInputStream());
//                messageFromClient = inputFromClient.readUTF();
//                System.out.println("Message = " + messageFromClient);
//                inputFromClient.close();
//                socket.close();
//            }
//        } catch (IOException ex) {
//            Logger.getLogger(SoulFightServer.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        
//    }
    
    
    
}
