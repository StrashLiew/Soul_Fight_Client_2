/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soulfightserver;

import com.example.soul_fight.RoomSettings;
import java.util.ArrayList;

/**
 *
 * @author User
 */
public class WaitingRoom implements Runnable {
  
   // public static ArrayList<ClientHandler> players = new ArrayList<>();  
    int roomID;
    public ClientHandler player1;
    ClientHandler player2;
    public RoomSettings roomSettings;
    boolean startMatch;
    
    WaitingRoom(ClientHandler player1, RoomSettings roomSettings){
        this.player1 = player1;
        this.roomSettings = roomSettings;
        this.roomID = 52069;
        this.startMatch = false;
    }
     
    public void addPlayer(ClientHandler player2){
        this.player2 = player2;
        if(this.player1!=null){
            this.player1.notifyPlayerJoin(player2.clientName);
            System.out.println(player2.clientName + " has been added to "+player1.clientName+"'s Room");          
        }       
    }
    
    public void matchStart(){
        System.out.println("Match is starting " + player1.clientName+ " "+ player2.clientName);
        startMatch = true;
        runGame();
    }
    
    public void runGame(){
        //run the Game Thread
        Game game = new Game(this.player1, this.player2);   
        player1.inGame = game;
        player2.inGame = game;
        Thread gameThread = new Thread(game);
        gameThread.start();
        System.out.println("Game Thread started");
    }
    
    @Override
    public void run(){
        System.out.println(player1.clientName + "'s Room has been built.");
        
    }
}
